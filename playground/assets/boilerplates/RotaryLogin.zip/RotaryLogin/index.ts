export { default } from "./RotaryLogin";
