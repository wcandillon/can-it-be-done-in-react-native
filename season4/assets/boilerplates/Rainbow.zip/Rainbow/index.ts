export { default } from "./Rainbow";
