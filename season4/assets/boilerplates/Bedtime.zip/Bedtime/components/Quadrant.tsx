const Quadrant = () => {
  return null;
};

export default Quadrant;
