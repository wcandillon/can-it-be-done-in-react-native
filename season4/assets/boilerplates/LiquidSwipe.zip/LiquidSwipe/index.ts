export { default, assets } from "./LiquidSwipe";
