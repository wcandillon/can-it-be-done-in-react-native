import React from "react";
import { View } from "react-native";

interface BackgroundProps {}

const Background = () => {
  return <View />;
};

export default Background;
