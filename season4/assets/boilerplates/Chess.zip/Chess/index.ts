export { default } from "./Chess";
import { PIECES } from "./Piece";

export const assets = Object.values(PIECES);
