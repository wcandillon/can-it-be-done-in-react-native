import { StatusBar } from "expo-status-bar";
import React from "react";
import { Dimensions, StyleSheet } from "react-native";
import { ScrollView } from "react-native-gesture-handler";

import Item from "./Item";
import { items } from "./Model";

const styles = StyleSheet.create({
  scrollView: {
    backgroundColor: "black",
  },
});

const Channel = () => {
  return (
    <>
      <StatusBar hidden />
      <ScrollView style={styles.scrollView}>
        {items.map((item, index) => (
          <Item item={item} key={index} />
        ))}
      </ScrollView>
    </>
  );
};

export default Channel;
