export { default } from "./Duolingo";

export const assets = [require("./assets/character.png")];
